from ex115.lib.interface import *
from ex115.lib.arquivo import *
from time import sleep

arq = 'arquivo.txt'

if not arquivo_existe(arq):
    criar_arquivo(arq)


while True:
    resposta = menu(['Ver Lista', 'Registar Pessoa', 'Sair do Sistema'])
    if resposta == 1:
        # opção de lista o conteúdo de um arquivo
        ler_arquivo(arq)
    elif resposta == 2:
        cabecalho('NOVO REGISTO')
        nome = str(input('Nome: '))
        idade = leiaInt('Idade: ')
        registar_pessoa(arq, nome, idade)
    elif resposta == 3:
        cabecalho('Programa finalizado-')
        break
    else:
        print('\033[0;31mERRO! Digite uma opção válida.\033[m')
    sleep(1)